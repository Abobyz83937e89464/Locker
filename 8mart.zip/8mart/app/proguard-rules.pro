# Add project specific ProGuard rules here.
# By default, the flags in this file are appended to flags specified
# in the SDK tools/proguard/proguard-android.txt
# You can include any file here.
